"""
Extract all code cells from the notebook and run them as a single Python script.
Applies runtime patches for macOS + Python 3.13 compatibility.
"""
import json, sys, traceback, io, contextlib, os

NB_PATH = "Document-QA-RAG/RAG_Assignment.ipynb"

with open(NB_PATH, "r", encoding="utf-8") as f:
    nb = json.load(f)

code_cells = [(i, cell) for i, cell in enumerate(nb["cells"]) if cell["cell_type"] == "code"]
print(f"Found {len(code_cells)} code cells to execute.\n")

# -------------------------------------------------------------------
# PATCHES: fix known issues at source-code level before exec
# -------------------------------------------------------------------
PATCHES = [
    # Fix 1: langchain.text_splitter (deprecated in langchain >=0.2)
    (
        "from langchain.text_splitter import RecursiveCharacterTextSplitter\n",
        "try:\n    from langchain_text_splitters import RecursiveCharacterTextSplitter\nexcept ImportError:\n    from langchain.text_splitter import RecursiveCharacterTextSplitter\n"
    ),
    (
        "from langchain.schema import Document\n",
        "try:\n    from langchain_core.documents import Document\nexcept ImportError:\n    from langchain.schema import Document\n"
    ),
    # Fix 2: Disable show_progress_bar in SentenceTransformer.encode to avoid
    #         multiprocessing segfault on macOS + Python 3.13
    (
        "return model.encode(\n        texts, batch_size=batch_size, show_progress_bar=True,\n        convert_to_numpy=True, normalize_embeddings=True\n    ).astype(np.float32)\n",
        "return model.encode(\n        texts, batch_size=batch_size, show_progress_bar=False,\n        convert_to_numpy=True, normalize_embeddings=True\n    ).astype(np.float32)\n"
    ),
    # Fix 3: Alternative form (in case multiline didn't match)
    (
        "show_progress_bar=True,",
        "show_progress_bar=False,"
    ),
]

def apply_patches(source: str) -> str:
    for old, new in PATCHES:
        source = source.replace(old, new)
    return source

os.chdir("Document-QA-RAG")

ns = {"__name__": "__main__"}
all_outputs = []

for cell_idx, (nb_idx, cell) in enumerate(code_cells):
    source = "".join(cell["source"])
    if not source.strip():
        continue

    source = apply_patches(source)

    print(f"\n{'='*60}")
    print(f"CELL {cell_idx+1} (notebook index {nb_idx})")
    print('='*60)
    print(source[:200] + ("..." if len(source) > 200 else ""))
    print("-"*60)

    captured = io.StringIO()
    try:
        with contextlib.redirect_stdout(captured):
            exec(compile(source, f"<cell {cell_idx+1}>", "exec"), ns)
        output = captured.getvalue()
        if output:
            print(output)
        print(f"✅ Cell {cell_idx+1} OK")
        all_outputs.append((cell_idx+1, "OK", output))
    except SystemExit:
        output = captured.getvalue()
        if output:
            print(output)
        print(f"✅ Cell {cell_idx+1} OK (sys.exit)")
        all_outputs.append((cell_idx+1, "OK", output))
    except Exception as e:
        output = captured.getvalue()
        if output:
            print(output)
        err = traceback.format_exc()
        print(f"❌ Cell {cell_idx+1} ERROR: {e}")
        print(err)
        all_outputs.append((cell_idx+1, "ERROR", str(e)))

print(f"\n{'='*60}")
print("FINAL SUMMARY")
print('='*60)
for num, status, _ in all_outputs:
    icon = "✅" if status == "OK" else "❌"
    print(f"  {icon} Cell {num:3d}: {status}")

errors = [x for x in all_outputs if x[1] == "ERROR"]
print(f"\nTotal: {len(all_outputs)} cells, {len(errors)} error(s)")
if not errors:
    print("\n🎉 ALL CELLS COMPLETED SUCCESSFULLY!")

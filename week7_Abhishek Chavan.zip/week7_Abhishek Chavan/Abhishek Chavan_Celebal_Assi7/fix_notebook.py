"""
Patch RAG_Assignment.ipynb to fix deprecated LangChain imports, then run it.
"""
import json, re, subprocess, sys

NB_PATH = "Document-QA-RAG/RAG_Assignment.ipynb"

with open(NB_PATH, "r", encoding="utf-8") as f:
    nb = json.load(f)

FIXES = [
    # Old import -> new import (langchain.text_splitter)
    (
        "from langchain.text_splitter import RecursiveCharacterTextSplitter\n",
        "try:\n    from langchain_text_splitters import RecursiveCharacterTextSplitter\nexcept ImportError:\n    from langchain.text_splitter import RecursiveCharacterTextSplitter\n"
    ),
    # Old import -> new import (langchain.schema.Document)
    (
        "from langchain.schema import Document\n",
        "try:\n    from langchain_core.documents import Document\nexcept ImportError:\n    from langchain.schema import Document\n"
    ),
]

patched = 0
for cell in nb["cells"]:
    if cell["cell_type"] != "code":
        continue
    source = cell["source"]
    new_source = []
    for line in source:
        matched = False
        for old, new in FIXES:
            if old in line:
                new_source.append(line.replace(old, new))
                matched = True
                patched += 1
                break
        if not matched:
            new_source.append(line)
    cell["source"] = new_source
    # Clear old error outputs so nbconvert re-runs cleanly
    cell["outputs"] = []
    cell["execution_count"] = None

print(f"Patched {patched} import(s).")

with open(NB_PATH, "w", encoding="utf-8") as f:
    json.dump(nb, f, indent=1, ensure_ascii=False)

print(f"Saved patched notebook: {NB_PATH}")

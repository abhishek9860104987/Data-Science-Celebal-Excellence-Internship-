# 📄 Document Question Answering System using Retrieval-Augmented Generation (RAG)

> **University Assignment — AI & NLP Engineering**  
> Built with LangChain · FAISS · HuggingFace · Sentence Transformers · Flan-T5

---

## 🧠 Project Overview

This project implements a complete **Retrieval-Augmented Generation (RAG)** pipeline for **Document Question Answering**. Instead of relying on a language model's pre-trained knowledge alone, RAG retrieves relevant context from your own custom documents and uses it to generate grounded, accurate answers.

The system can ingest **PDF files**, **plain text files**, and **HuggingFace datasets**, build a **FAISS vector database**, and answer natural language questions with citations to the source material.

---

## 🎯 Objectives

- ✅ Ingest and preprocess PDF, TXT, and HuggingFace dataset documents
- ✅ Split text into configurable chunks using `RecursiveCharacterTextSplitter`
- ✅ Generate dense embeddings with `sentence-transformers/all-MiniLM-L6-v2`
- ✅ Build and persist a **FAISS** vector database
- ✅ Implement **Hybrid Search** (Vector Search + BM25 Keyword Search)
- ✅ Implement **CrossEncoder Reranking** for improved retrieval quality
- ✅ Generate grounded answers with `google/flan-t5-base`
- ✅ Validate with 10+ sample questions and log all results
- ✅ Generate a full **Metrics Report**
- ✅ Run **experiments** across chunk sizes, overlaps, and Top-K values

---

## 📁 Folder Structure

```
Document-QA-RAG/
│
├── RAG_Assignment.ipynb       ← Main Jupyter Notebook (end-to-end RAG system)
├── README.md                  ← Project documentation (this file)
├── requirements.txt           ← Python package dependencies
│
├── dataset/
│   ├── pdfs/                  ← Place your PDF documents here
│   ├── text/                  ← Place your TXT documents here
│   └── hf_dataset/            ← HuggingFace dataset cache (auto-managed)
│
├── vector_db/                 ← FAISS index and metadata (auto-generated)
│
├── outputs/
│   ├── generated_answers.txt  ← All generated Q&A pairs (auto-generated)
│   ├── validation_logs.txt    ← Detailed validation logs (auto-generated)
│   └── metrics_report.txt     ← System metrics and configuration (auto-generated)
│
└── screenshots/               ← Place assignment screenshots here
```

---

## 🏗️ System Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                     RAG SYSTEM ARCHITECTURE                     │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  INDEXING PIPELINE (Offline)          QUERY PIPELINE (Online)   │
│  ─────────────────────────────        ──────────────────────    │
│                                                                 │
│  [PDF / TXT / HF Dataset]            [User Question]           │
│           │                                   │                 │
│           ▼                                   ▼                 │
│    [Text Extraction]              [Query Embedding]             │
│           │                           (MiniLM-L6-v2)           │
│           ▼                                   │                 │
│    [Text Cleaning]                            ▼                 │
│           │                       [FAISS Similarity Search]     │
│           ▼                           +  [BM25 Search]          │
│    [Text Chunking]                            │                 │
│    (RecursiveChar)                            ▼                 │
│           │                      [Hybrid Score Fusion]          │
│           ▼                                   │                 │
│  [Embedding Generation]                       ▼                 │
│    (MiniLM-L6-v2)                [CrossEncoder Reranking]       │
│           │                                   │                 │
│           ▼                                   ▼                 │
│  [FAISS Vector Index]             [Prompt Construction]         │
│    (Saved to disk)                            │                 │
│                                               ▼                 │
│                                  [Flan-T5 Answer Generation]    │
│                                               │                 │
│                                               ▼                 │
│                                    [Grounded Answer]            │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## 🔄 Workflow Diagram (Mermaid)

```mermaid
flowchart TD
    A[📂 Document Sources] --> B[Document Loader]
    B --> C{File Type?}
    C -->|PDF| D[PyMuPDF / pypdf]
    C -->|TXT| E[Text Reader]
    C -->|HuggingFace| F[datasets Library]
    D --> G[Raw Text]
    E --> G
    F --> G
    G --> H[Text Cleaner]
    H --> I[RecursiveCharacterTextSplitter]
    I --> J[Text Chunks]
    J --> K[SentenceTransformer Embedder]
    K --> L[Dense Vectors]
    L --> M[(FAISS Vector DB)]
    M --> N[Saved to vector_db/]

    P[❓ User Question] --> Q[Query Embedder]
    Q --> R[FAISS Vector Search]
    J --> S[BM25 Keyword Search]
    P --> S
    R --> T[Hybrid Fusion]
    S --> T
    T --> U[CrossEncoder Reranker]
    U --> V[Top-K Chunks]
    V --> W[Prompt Builder]
    P --> W
    W --> X[Flan-T5 Base LLM]
    X --> Y[✅ Grounded Answer]
    Y --> Z[outputs/]
```

---

## ⚙️ Installation

### 1. Clone / Download the project

```bash
# If using git
git clone <repo-url>
cd Document-QA-RAG
```

### 2. Create a virtual environment (recommended)

```bash
python -m venv venv
source venv/bin/activate       # Linux / macOS
venv\Scripts\activate          # Windows
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Launch Jupyter Notebook

```bash
jupyter notebook RAG_Assignment.ipynb
```

---

## 📋 Requirements

| Category | Package | Version |
|----------|---------|---------|
| Deep Learning | `torch` | ≥ 2.0.0 |
| Transformers | `transformers` | ≥ 4.35.0 |
| Embeddings | `sentence-transformers` | ≥ 2.2.2 |
| RAG Framework | `langchain` | ≥ 0.1.0 |
| Vector DB | `faiss-cpu` | ≥ 1.7.4 |
| PDF Processing | `pymupdf`, `pypdf` | ≥ 1.23.0 |
| Keyword Search | `rank-bm25` | ≥ 0.2.2 |
| HuggingFace | `datasets`, `huggingface-hub` | ≥ 2.14.0 |
| Data | `numpy`, `pandas` | ≥ 1.24.0 |
| Utilities | `tqdm`, `python-dotenv` | ≥ 4.65.0 |

---

## 🛠️ Technologies Used

| Component | Technology |
|-----------|-----------|
| **Embedding Model** | `sentence-transformers/all-MiniLM-L6-v2` |
| **Language Model** | `google/flan-t5-base` |
| **Vector Database** | FAISS (Facebook AI Similarity Search) |
| **RAG Framework** | LangChain |
| **Keyword Search** | BM25 (rank-bm25) |
| **Reranker** | `cross-encoder/ms-marco-MiniLM-L-6-v2` |
| **PDF Parser** | PyMuPDF + pypdf |
| **HF Datasets** | HuggingFace `datasets` library |

---

## 📖 Project Workflow

1. **Document Ingestion** — Load PDFs, TXTs, and HuggingFace datasets from `dataset/`
2. **Text Extraction** — Extract raw text from each document
3. **Text Cleaning** — Normalize whitespace, remove noise
4. **Text Chunking** — Split into overlapping chunks using `RecursiveCharacterTextSplitter`
5. **Embedding Generation** — Encode chunks with `all-MiniLM-L6-v2` (384-dim vectors)
6. **FAISS Indexing** — Store vectors in a flat L2 index, save to `vector_db/`
7. **Query Processing** — Embed user question into the same vector space
8. **Hybrid Retrieval** — Combine FAISS + BM25 scores with Reciprocal Rank Fusion
9. **CrossEncoder Reranking** — Optionally rerank retrieved chunks
10. **Answer Generation** — Construct context prompt → Flan-T5 → Grounded answer
11. **Output Saving** — Persist answers, validation logs, and metrics report

---

## ▶️ How to Run

### Option A: Run All Cells (Recommended)

1. Open `RAG_Assignment.ipynb` in Jupyter
2. Go to **Kernel → Restart & Run All**
3. Wait for all cells to complete
4. Check `outputs/` folder for results

### Option B: Add Your Own Documents

1. Place PDF files into `dataset/pdfs/`
2. Place TXT files into `dataset/text/`
3. Run all cells — the system auto-detects your documents

### Option C: Ask Custom Questions

In **Section 12 (Testing)**, modify the `SAMPLE_QUESTIONS` list to ask your own questions.

---

## 📊 Expected Output

After running the notebook you will find:

| File | Contents |
|------|----------|
| `outputs/generated_answers.txt` | All Q&A pairs with timestamps |
| `outputs/validation_logs.txt` | Detailed logs per question (context, score, time) |
| `outputs/metrics_report.txt` | System configuration and performance metrics |
| `vector_db/` | FAISS index files (`.index` + `.pkl`) |

---

## 🖼️ Sample Screenshots Placeholder

> Place your Jupyter notebook screenshots in the `screenshots/` folder.

| Screenshot | Description |
|-----------|-------------|
| `screenshots/01_ingestion.png` | Document loading output |
| `screenshots/02_chunking.png` | Chunking results table |
| `screenshots/03_embeddings.png` | Embedding generation stats |
| `screenshots/04_faiss.png` | FAISS index creation |
| `screenshots/05_retrieval.png` | Retrieval results with scores |
| `screenshots/06_answers.png` | Generated Q&A pairs |
| `screenshots/07_experiments.png` | Experiment comparison table |

---

## 🧪 Experimental Results

### Chunk Size Experiment

| Chunk Size | Overlap | Num Chunks | Retrieval Quality |
|-----------|---------|-----------|------------------|
| 300 | 20 | High | Good for precise retrieval |
| 500 | 50 | Medium | **Best balance** |
| 700 | 100 | Low | Better context, less precision |

### Retrieval Method Experiment

| Method | Precision | Notes |
|--------|---------|-------|
| Vector Only | Good | Fast, semantic |
| Hybrid (Vector + BM25) | Better | Handles keyword queries |
| Hybrid + Reranking | **Best** | Most accurate, slower |

---

## 🚀 Future Improvements

- [ ] Add support for Word (`.docx`) and HTML documents
- [ ] Integrate a more powerful LLM (e.g., `Llama-3`, `Mistral`)
- [ ] Implement streaming token generation
- [ ] Add a Gradio/Streamlit web UI
- [ ] Support multi-document citation with page numbers
- [ ] Add RAGAS evaluation framework for automated metrics
- [ ] Implement conversational memory (multi-turn QA)
- [ ] Deploy as a REST API with FastAPI

---

## 📚 References

1. Lewis, P. et al. (2020). *Retrieval-Augmented Generation for Knowledge-Intensive NLP Tasks*. NeurIPS.
2. Reimers, N. & Gurevych, I. (2019). *Sentence-BERT: Sentence Embeddings using Siamese BERT-Networks*. EMNLP.
3. Johnson, J. et al. (2021). *Billion-scale similarity search with GPUs*. IEEE.
4. Robertson, S. & Zaragoza, H. (2009). *The Probabilistic Relevance Framework: BM25 and Beyond*.
5. Nogueira, R. & Cho, K. (2019). *Passage Re-ranking with BERT*. arXiv.
6. LangChain Documentation: https://docs.langchain.com
7. HuggingFace Model Hub: https://huggingface.co/models
8. FAISS Documentation: https://faiss.ai

---

## 👤 Author

**University Assignment — Document QA RAG System**  
*AI & Natural Language Processing Engineering*

---

*Generated with Python 3.11+ | LangChain | FAISS | HuggingFace Transformers*

"""
Normalize the notebook (add missing cell IDs, fix format), then run it.
"""
import json, uuid, subprocess, sys

NB_PATH = "Document-QA-RAG/RAG_Assignment.ipynb"

with open(NB_PATH, "r", encoding="utf-8") as f:
    nb = json.load(f)

# Ensure nbformat 4.5 compatibility: add 'id' to every cell
for cell in nb["cells"]:
    if "id" not in cell:
        cell["id"] = str(uuid.uuid4())[:8]

# Ensure nbformat version is set correctly
nb["nbformat"] = 4
nb["nbformat_minor"] = 5

with open(NB_PATH, "w", encoding="utf-8") as f:
    json.dump(nb, f, indent=1, ensure_ascii=False)

print("Notebook normalized (cell IDs added, nbformat set to 4.5)")
print("Running notebook with nbconvert...")

result = subprocess.run(
    [
        sys.executable, "-m", "jupyter", "nbconvert",
        "--to", "notebook",
        "--execute",
        "--inplace",
        "--ExecutePreprocessor.timeout=600",
        "--ExecutePreprocessor.kernel_name=python3",
        "RAG_Assignment.ipynb"
    ],
    cwd="Document-QA-RAG",
    capture_output=False,
    text=True
)
sys.exit(result.returncode)
